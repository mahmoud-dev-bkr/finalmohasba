const $button = document.querySelector("#sidebar-toggle");
const $wrapper = document.querySelector("#wrapper");

const sideImg = document.getElementById("sideImg");
const sidebarNav = document.querySelector(".sidebar-nav");

const tooltipTriggerList = document.querySelectorAll(
  '[data-bs-toggle="tooltip"]'
);
const tooltipList = [...tooltipTriggerList].map(
  (tooltipTriggerEl) => new bootstrap.Tooltip(tooltipTriggerEl)
);

$button.addEventListener("click", (e) => {
  e.preventDefault();
  $wrapper.classList.toggle("toggled");
});

function toggleZoomScreen() {
  document.body.style.zoom = "80%";
}

toggleZoomScreen();

// Accordion Action
const accordionItem = document.querySelectorAll(".clicked-item");

accordionItem.forEach((el) =>
  el.addEventListener("click", () => {
    if (el.classList.contains("active")) {
      el.classList.remove("active");
    } else {
      accordionItem.forEach((el2) => el2.classList.remove("active"));
      el.classList.add("active");
    }
  })
);

// setup
const data = {
  labels: [
    "2023 January ",
    "2023 February",
    "2023 March",
    "2023 April",
    "2023 May",
    "2023 June",
    "2023 July",
  ],
  datasets: [
    {
      label: "Weekly Sales",
      data: [12, 10, 8, 6, 4, 2, 0],
      borderWidth: 1,
    },
  ],
};

// config
const config = {
  type: "line",
  data,
  options: {
    scales: {
      y: {
        ticks: {
          callback: function (value) {
            return value + "k";
          },
        },
      },
    },
  },
};

// render init block
const myChart = new Chart(document.getElementById("myChart"), config);

// Instantly assign Chart.js version
const chartVersion = document.getElementById("chartVersion");
chartVersion.innerText = Chart.version;
